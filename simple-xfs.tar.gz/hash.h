#ifndef HASH_H
#define HASH_H

std::size_t get_hash(std::string fn);

#endif //HASH_H
