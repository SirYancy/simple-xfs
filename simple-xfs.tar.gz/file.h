#ifndef FILE_H
#define FILE_H

int GetFileList(char *buffer);

#endif //FILE_H
